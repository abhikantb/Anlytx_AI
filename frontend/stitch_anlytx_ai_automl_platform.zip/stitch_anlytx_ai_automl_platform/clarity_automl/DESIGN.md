---
name: Clarity AutoML
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4850'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#006b5f'
  on-secondary: '#ffffff'
  secondary-container: '#6df5e1'
  on-secondary-container: '#006f64'
  tertiary: '#00647c'
  on-tertiary: '#ffffff'
  tertiary-container: '#007f9d'
  on-tertiary-container: '#fafdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#b7eaff'
  tertiary-fixed-dim: '#6cd3f7'
  on-tertiary-fixed: '#001f28'
  on-tertiary-fixed-variant: '#004e61'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.025em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system positions automated machine learning and generative data conversation as inviting, intuitive, and stress-free for non-technical creators, domain specialists, and business analysts. It rejects intimidating, dense terminal interfaces and convoluted pipeline nodes in favor of a modern, human-centric design language balancing software utility with conversational clarity.

The visual style blends modern corporate clarity with tactile, breezy digital software elements. It features crisp milk-and-slate surfaces, airy negative space, approachable rounded silhouettes, and translucent accents. Micro-interactions and state cues feel instantaneous, supportive, and communicative, replacing opaque algorithmic uncertainty with transparent visual feedback and plain-language scaffolding.

## Colors
The palette uses crisp slates and layered cool teals to evoke analytical confidence, cognitive calmness, and immediate intelligibility.

- **Primary (`#0284c7` / Sky 600):** Drives primary actions, system status headers, active conversational paths, and interactive chart highlights.
- **Secondary (`#14b8a6` / Teal 500):** Signifies model confidence, automated success states, data ingestion validation, and progressive metrics.
- **Tertiary (`#0891b2` / Cyan 600):** Anchors AI prompt hints, exploratory queries, interactive tokens, and supplemental data trends.
- **Neutral (`#64748b` / Slate 500):** Calibrates layout structure, subtle card perimeters, inactive controls, and balanced typographic hierarchy.

Canvas surfaces rely on pure white (`#ffffff`) elevated above base slate tints (`#f8fafc` / Slate 50), ensuring sharp contrast without visual glare. Dark text values stay strictly within deep charcoal-slates (`#0f172a` and `#334155`) to maintain WCAG AAA compliance.

## Typography
Plus Jakarta Sans is used uniformly across display, body, and label roles. Its geometric build, open counters, and humanist proportions preserve legibility across statistical tables, chat bubbles, and mobile screens while maintaining a warm, approachable character.

Headlines employ tighter letter-spacing and strong weights (`600`, `700`) to anchor scanning eyes. Body text uses relaxed line heights (1.5x–1.625x) to prevent reader fatigue across lengthy machine learning summaries, schema explanations, and conversational prompts.

## Layout & Spacing
The layout follows a fluid-responsive mobile-first philosophy built upon a steady 8pt baseline rhythm, shifting smoothly across three primary viewport tiers:

- **Mobile (< 768px):** Single-column layout. Margin sits at `1rem` with `1rem` column gutters. Chat inputs, metric snapshots, and AutoML step indicators dock to the base of the viewport for comfortable thumb reach.
- **Tablet (768px - 1024px):** 6-column fluid structure. Outer margins scale to `1.5rem`. Context panels and chat histories sit side-by-side or collapse smoothly into accessible floating sheets.
- **Desktop (> 1024px):** 12-column layout maxing out at `1280px` canvas width to preserve scan-line comfort. Outer canvas margins expand to `2.5rem` with `1.5rem` gutters. The conversational workbench occupies a structured split view: interactive prompts and exploratory dialogues inhabit 5 columns, while real-time training metrics, dataset previews, and model insights inhabit the remaining 7 columns.

## Elevation & Depth
Depth is constructed through ambient tonal layering, gossamer hairline borders, and weightless, cyan-tinted atmospheric shadows rather than heavy structural drop shadows.

- **Level 0 (Base Canvas):** Lightest tinted neutral background (`#f8fafc`).
- **Level 1 (Cards & Chat Containers):** Pure white fill (`#ffffff`), reinforced by a subtle `1px` border of Slate 200 (`rgba(226, 232, 240, 0.8)`) and an ultra-diffuse ambient shadow: `0 4px 20px -2px rgba(15, 23, 42, 0.04)`.
- **Level 2 (Hover States, Active Cards, Popovers):** Elevated surface with dynamic ambient lift: `0 10px 25px -4px rgba(2, 132, 199, 0.08)`, accented by primary border tinting (`rgba(2, 132, 199, 0.2)`).
- **Level 3 (Modals, Overlays, Floating Prompts):** Highest surface, utilizing soft frosted backdrops (`backdrop-blur-md` with `rgba(248, 250, 252, 0.75)`) and balanced deep diffusion: `0 20px 35px -8px rgba(15, 23, 42, 0.12)`.

## Shapes
The shape vocabulary uses generous curvature to soften technical subject matter. Primary functional surfaces, dataset inspection modules, and conversational stream wrappers share a standard `rounded-2xl` contour (`1rem` to `1.5rem`), evoking tactile comfort. Small interactive controls like buttons, tag filters, and search inputs leverage standard `0.5rem` to `0.75rem` radiuses, while status badges and interactive action pills utilize complete semi-circular radiuses (`9999px`).

## Components

### Buttons
- **Primary:** Filled Sky 600 (`#0284c7`) with white text, transitioning to `#0369a1` on hover. Elevated via a subtle base shadow (`0 2px 8px rgba(2, 132, 199, 0.25)`). Minimum touch target: 44px on mobile.
- **Secondary:** White background with a hairline border (`#cbd5e1`) and `#0f172a` typography. Gains a sky-tinted wash (`#f0f9ff`) and border highlight on hover.
- **Ghost / Action Pills:** Transparent backgrounds with `#0284c7` text, intended for inline conversational suggestions and quick query prompts.

### Cards
- Built using `rounded-2xl` geometry with white backgrounds and hairline borders (`#e2e8f0`).
- Headers feature clear hierarchy: medium-bold titles accompanied by small helper tooltips or automated confidence badges. Internal component padding scales between `1rem` on mobile and `1.5rem` on desktop.

### Chips & Badges
- **Query Suggestion Chips:** Soft Teal/Sky tints (`#f0fdfa`, `#f0f9ff`) with `9999px` pill radius, subtle borders, and interactive hover shifts.
- **Status Badges:** Small, focused tags signaling model training progress (`Running`, `Tuned`, `Deployable`). Pair saturated status indicators (emerald, amber, cyan) with muted background fills.

### Form Inputs & Chat Bar
- Chat input uses a prominent floating bar with a `rounded-2xl` enclosure, pure white background, and a faint border that deepens to `#0284c7` with a matching focus ring (`ring-2 ring-sky-500/20`).
- Traditional form fields feature floating labels or high-contrast hints, avoiding jargon in favor of plain-language guidance.

### Checkboxes & Radios
- Rounded controls with subtle `1px` slate borders. Active selection triggers a lively fill in Sky 600 with white check/dot vectors, paired with a subtle spring scale animation.

### Visual Progress Cues (AutoML Lifecycle)
- Multi-step pipelines (Ingestion, Preprocessing, Feature Engineering, Training, Evaluation) leverage segmented progress rails with gradient fills (Sky 600 to Teal 500).
- Live operations feature pulsing micro-glows and concise status strings, maintaining continuous visibility into model generation without cluttering the screen.